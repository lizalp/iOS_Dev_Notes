//: [Previous](@previous)

import Foundation

//board[9] = 1

//: [Next](@next)
