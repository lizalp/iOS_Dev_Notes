//
//  ViewController.swift
//  Fakestagram
//
//  Created by Diplomado on 15/03/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

